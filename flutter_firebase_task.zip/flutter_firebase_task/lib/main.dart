import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:task/screen/signin_screen.dart';
import 'package:task/service/auth-service.dart'; // นำเข้าไฟล์บริการ Authentication

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(); // เริ่มต้น Firebase
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.pink),
        useMaterial3: true,
      ),
      home: const SigninScreen(), // เริ่มต้นที่หน้า Signin
    );
  }
}

class TodoApp extends StatefulWidget {
  const TodoApp({super.key});

  @override
  State<TodoApp> createState() => _TodoAppState();
}

class _TodoAppState extends State<TodoApp> {
  late TextEditingController _texteditController;
  late TextEditingController _descriptionController;

  @override
  void initState() {
    super.initState();
    _texteditController = TextEditingController();
    _descriptionController = TextEditingController();
  }

  void _logout() async {
    await FirebaseAuth.instance.signOut(); // ทำการ Sign out จาก Firebase
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const SigninScreen()), // กลับไปที่หน้า Signin
    );
  }

  void addTodoHandle(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Add new task"),
          content: SizedBox(
            width: 120,
            height: 180,
            child: Column(
              children: [
                TextField(
                  controller: _texteditController,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: "Input your task",
                  ),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _descriptionController,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: "Description",
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                CollectionReference tasks = FirebaseFirestore.instance.collection("tasks");
                tasks.add({
                  'name': _texteditController.text,
                  'description': _descriptionController.text,
                  'status': false,
                }).then((res) {
                  print("Task added: $res");
                }).catchError((onError) {
                  print("Failed to add new Task");
                });
                _texteditController.clear();
                _descriptionController.clear();
                Navigator.pop(context);
              },
              child: const Text("Save"),
            ),
          ],
        );
      },
    );
  }

  void _editTodo(String docId, int index) {
    _texteditController.text = ""; // เคลียร์ค่าเดิม
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Edit task"),
          content: TextField(
            controller: _texteditController,
            decoration: const InputDecoration(labelText: "Edit your task"),
          ),
          actions: [
            TextButton(
              onPressed: () {
                // อัปเดตเอกสารใน Firestore
                FirebaseFirestore.instance.collection("tasks").doc(docId).update({
                  'name': _texteditController.text,
                }).then((res) {
                  print("Task updated: $docId");
                }).catchError((onError) {
                  print("Failed to update task");
                });
                _texteditController.clear();
                Navigator.pop(context);
              },
              child: const Text("Save"),
            ),
          ],
        );
      },
    );
  }

  void _deleteTodo(String docId) {
    // ลบเอกสารจาก Firestore
    FirebaseFirestore.instance.collection("tasks").doc(docId).delete().then((_) {
      print("Task deleted: $docId");
    }).catchError((onError) {
      print("Failed to delete task");
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Todo"),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: _logout, // เมื่อกดจะทำการ logout และกลับไปหน้า Signin
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection("tasks").snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          return ListView.builder(
            itemCount: snapshot.data?.docs.length,
            itemBuilder: (context, index) {
              var item = snapshot.data?.docs[index];
              return ListTile(
                title: Text(item!['name']),
                subtitle: Text(item['description'] ?? ''),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.edit),
                      onPressed: () => _editTodo(item.id, index),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete),
                      onPressed: () => _deleteTodo(item.id),
                    ),
                  ],
                ),
                onTap: () {
                  // Add logic for marking as complete if needed
                },
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          addTodoHandle(context);
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
