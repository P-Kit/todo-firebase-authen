# Task application

## Firebase package

Install firebase package to project

```
  flutter pub add cloud_firestore
  flutter pub add firebase_auth
  flutter pub add firebase_core
```

## Installation

```
flutter pub get
```
